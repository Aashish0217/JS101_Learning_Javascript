//Problem 2: Print the odd numbers from 0 till the given limit

let x=0 ;
while(x<=100){
  if (x%2!=0){
    console.log(x);
  }
  x++;
}