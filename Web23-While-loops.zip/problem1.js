//Problem 1: Print the numbers from the given starting point till ending point (including both start and end)

//let starting from "1" and endng on "20"

let x=1;

while(x<=20){
  console.log(x);
  x++;
  
}