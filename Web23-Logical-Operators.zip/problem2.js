//Problem 2 : Given any character, if it is a vowel print "Vowel

let char= "e";

if (char=="a"|| char=="e" || char =="i"|| char == "o" || char=="u"){
  console.log("Vowel");
}else {
  console.log("Consonant");
}
