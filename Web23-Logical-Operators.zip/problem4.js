//Problem 4: Given 3 numbers (all different values), print which is greatest

let a = 12 ;
let b = 20 ;
let c = 25 ;

if (a>b && a>c){
  console.log(" a, is greatest");
}else if (b>a && b>c){
  console.log (" b , is greatest");
}else {
  console.log("c , is greatest");
}