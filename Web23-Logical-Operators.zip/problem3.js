//Problem 3 : Given and character if it is a consonant print "Consonant"

let char= "c";

if (char=="a"|| char=="e" || char =="i"|| char == "o" || char=="u"){
  console.log("Vowel");
}else {
  console.log("Consonant");
}
