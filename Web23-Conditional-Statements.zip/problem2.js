let age=20;
if (age>=18){
  console.log("Apply for licence");
}else {
  console.log("NA");
}