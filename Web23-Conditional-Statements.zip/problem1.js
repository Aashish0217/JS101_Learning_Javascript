let number = 15;

if (number%3 ==0){
  console.log("Multipe of three ")
}