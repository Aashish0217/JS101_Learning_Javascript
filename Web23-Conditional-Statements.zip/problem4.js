//User data stored in database 
let database_username = "217ash";
let database_password = "ashish";

//For login
let username = "217ash";
let password = "ashish";

if (database_username==username){
  if (database_password==password){
    console.log ("Login successfully");
  }else ("Password incorrect");
}
else{
("wrong credentials") ; 
} 