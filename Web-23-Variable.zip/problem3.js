let name = "aashish_chauhan";
console.log(name);
console.log(typeof(name));
let age = 20;
console.log(age);
console.log(typeof(age));