console.log("masai_school");

console.log("A_Transformation_in_Education");