let name = "aashish_chauhan";
console.log(name);

name = "vinod_singh_chauhan";
console.log(name);

name = "suman_chauhan";
console.log(name)
