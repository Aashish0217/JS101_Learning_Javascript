let name = "pushpa";

console.log(name)