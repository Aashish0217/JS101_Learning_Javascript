let name = "Albert";
console.log(name);
let school = "DPS";
console.log(school);
let grade = "A+"
console.log(grade);
let section = "A";
console.log(section);
let roll_no = 21;
console.log(roll_no);
let subject1 = "Maths";
let score1 = 99;
console.log(subject1,score1);
let subject2 = "English";
let score2 = 98;
console.log(subject2,score2);
let subject3 = "Sanskrit";
let score3 = 100;
console.log(subject3,score3);

